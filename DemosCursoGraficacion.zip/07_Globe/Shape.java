package com.example.globe;

public interface Shape {
    void draw(float[] viewProjectionMatrix);
}
