package com.example.renderizarcubo;

public interface Shape {
    void draw(float[] viewProjectionMatrix);
}
