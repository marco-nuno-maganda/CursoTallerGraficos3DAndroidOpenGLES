package com.example.multitexturecube;

public interface Shape {
    void draw(float[] viewProjectionMatrix);
}
