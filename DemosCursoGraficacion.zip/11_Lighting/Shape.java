package com.example.lighting;

public interface Shape {
    void draw(float[] viewMatrix, float[] projectionMatrix);
}
