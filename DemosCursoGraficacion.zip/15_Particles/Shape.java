package com.example.particles;

public interface Shape {
    void draw(float[] viewProjectionMatrix);
}
