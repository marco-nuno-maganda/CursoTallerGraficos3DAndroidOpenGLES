package com.example.skybox;

public interface Shape {
    void draw(float[] viewMatrix, float[] projectionMatrix);
}
