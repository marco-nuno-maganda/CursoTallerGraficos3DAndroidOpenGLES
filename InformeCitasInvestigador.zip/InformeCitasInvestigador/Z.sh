# Borar todos los pdfs
rm *.pdf
# Borar todos los archivos intermedios
rm *.aux *.bbl *.blg *.bcf *.out *.xml *.log

# Para esto, el sistema que implementaste debe generar los siguientes archivos
# MarcoNuno_Revista_2018_07_00.png # Grafica de citas para el articulo 2018_07
# MarcoNuno_Revista_2018_08_00.png # Grafica de citas para el articulo 2018_08
# ListadodeArticulos_y_Citas.png  # Grafica de citas para todos los articulos del REPO
# MarcoNuno_Revista_2018_07_00_IND.bib # Solo el BIB individual de ese articulo
# MarcoNuno_Revista_2018_07_00.bib    # El bib con todas las citas de este articulo
# MarcoNuno_Revista_2018_08_00_IND.bib # Solo el BIB individual de ese articulo
# MarcoNuno_Revista_2018_08_00.bib # El bib con todas las citas de este articulo
# Master.bib  # El bib con todos los articulos del REPOSITORIO


# Compilar primer listado
pdflatex MarcoNuno_Revista_2018_07_00.tex
biber MarcoNuno_Revista_2018_07_00
pdflatex MarcoNuno_Revista_2018_07_00.tex
pdflatex MarcoNuno_Revista_2018_07_00.tex

# Compilar segundo listado
pdflatex MarcoNuno_Revista_2018_08_00.tex
biber MarcoNuno_Revista_2018_08_00
pdflatex MarcoNuno_Revista_2018_08_00.tex
pdflatex MarcoNuno_Revista_2018_08_00.tex

# Compilar las "N" items del respositorio, cada una genera su propior documento PDF


# Compilar el documento "Principal"

pdflatex ListadodeArticulos_y_Citas.tex
biber ListadodeArticulos_y_Citas
pdflatex ListadodeArticulos_y_Citas.tex
pdflatex ListadodeArticulos_y_Citas.tex

# Paso antes de mostar el pdf: limpiar todos los archivos temporales
rm *.aux *.bbl *.blg *.bcf *.out *.xml *.log

evince ListadodeArticulos_y_Citas.pdf

